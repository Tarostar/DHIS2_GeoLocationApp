$("button").click(function()
{
document.write("vhvv");
}
<!--{
  $.getJSON("C:/New phd stuff/INF5750/Json Files/program.json",function(result){
alert("something wrong");
    $.each(result, function(i, field){
    $("ul").append("<li>"+field.name+"</li>");
      });
     
  });
});-->