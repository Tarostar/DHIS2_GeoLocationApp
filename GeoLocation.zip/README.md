DHIS2_GeoLocationApp
====================

Mandalorians Geo Location App for Oslo University Master Course INF5750.
